﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;

namespace DolgozatWPF
{
    public class Dolgozat
    {
        public string Nev { get; set; }
        public int Eletkor { get; set; }
        public int Pontszam { get; set; }
    }

    public partial class MainWindow : Window
    {
        private ObservableCollection<Dolgozat> dolgozatLista;

        public MainWindow()
        {
            InitializeComponent();
            KezdoAdatokBetoltese();
        }

        private void KezdoAdatokBetoltese()
        {
            dolgozatLista = new ObservableCollection<Dolgozat>
            {
                new Dolgozat { Nev = "Kiss Péter", Eletkor = 16, Pontszam = 87 },
                new Dolgozat { Nev = "Nagy Anna", Eletkor = 17, Pontszam = 92 },
                new Dolgozat { Nev = "Szabó Tamás", Eletkor = 16, Pontszam = 78 },
                new Dolgozat { Nev = "Tóth Éva", Eletkor = 18, Pontszam = 95 },
                new Dolgozat { Nev = "Varga Bence", Eletkor = 17, Pontszam = 81 },
                new Dolgozat { Nev = "Horváth Zsolt", Eletkor = 16, Pontszam = 65 },
                new Dolgozat { Nev = "Molnár Réka", Eletkor = 18, Pontszam = 89 },
                new Dolgozat { Nev = "Lakatos Dániel", Eletkor = 17, Pontszam = 72 }
            };

            dgDolgozatok.ItemsSource = dolgozatLista;
        }

        private void btnHozzaadas_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNev.Text))
            {
                MessageBox.Show("Kérlek, add meg a nevet!", "Hiányzó adat", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtEletkor.Text, out int eletkor) || !int.TryParse(txtPontszam.Text, out int pontszam))
            {
                MessageBox.Show("Az életkornak és a pontszámnak egész számnak kell lennie!", "Hibás formátum", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            dolgozatLista.Add(new Dolgozat
            {
                Nev = txtNev.Text.Trim(),
                Eletkor = eletkor,
                Pontszam = pontszam
            });

            txtNev.Clear();
            txtEletkor.Clear();
            txtPontszam.Clear();
            txtNev.Focus();
        }

        private void btnMentes_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("dolgozatok.txt"))
                {
                    sw.WriteLine("Nev;Eletkor;Pontszam");
                    foreach (var item in dolgozatLista)
                    {
                        sw.WriteLine($"{item.Nev};{item.Eletkor};{item.Pontszam}");
                    }
                }

                MessageBox.Show("Sikeres mentés a dolgozatok.txt fájlba!", "Mentés", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a mentéskor: {ex.Message}", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
